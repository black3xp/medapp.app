(function ($) {
    'use strict';
    $("#summernote").summernote({
        height: 450
    });
    $("#summernote-02").summernote({
        height: 450,
        airMode: true
    });

})(window.jQuery);